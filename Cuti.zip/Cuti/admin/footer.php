<footer class="main-footer">
        <div class="pull-right hidden-xs">
        </div>
        <strong> <a target="_blank"></a></strong>
      </footer>